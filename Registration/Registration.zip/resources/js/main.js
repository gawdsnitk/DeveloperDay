/*
 Author : Divya Mamgai
 */
(function ($, d, t) {
    var Globals = {
            CurrentField: 0,
            LastField: 0,
            BackgroundColors: [
                '#2C3E50',
                '#15324b',
                '#114b38',
                '#114623',
                '#212121'
            ]
        },
        $Object = {},
        Functions = {
            RegistrationFormOnSubmit: function (event) {
                event.stopPropagation();
                event.preventDefault();
                // $Object.RegistrationForm.ajaxSubmit({
                //     dataType: 'json',
                //     beforeSend: function () {
                //     },
                //     success: function () {
                //         alert('Done!');
                //     },
                //     error: function (response) {
                //         alert('Error!');
                //     }
                // });
                $.ajax({
                    url: 'https://docs.google.com/forms/d/e/1FAIpQLSf3ceojBwAyCAVUX00C7y7XwpdoDhGrU7a4iCUU-QpMG1dxog/formResponse',
                    data: {
                        'entry.529376273': $Object.RegistrationForm.find('#Name').val(),
                        'entry.2115095195': $Object.RegistrationForm.find('#RollNumber').val(),
                        'entry.1758952710': $Object.RegistrationForm.find('#Mobile').val(),
                        'entry.573930796': $Object.RegistrationForm.find('#EmailID').val(),
                        'entry.2137029182': $Object.RegistrationForm.find('#Branch').val(),
                        'entry.1921439926': $Object.RegistrationForm.find('#Degree').val(),
                        'entry.1648960160': $Object.RegistrationForm.find('#Year').val(),
                        'entry.2005315227': $Object.RegistrationForm.find('#InterestsAndSkills').val()
                    },
                    type: 'POST',
                    dataType: 'jsonp',
                    processData: true,
                    mimeType: 'application/javascript',
                    success: function () {
                        alert('Success!');
                    },
                    error: function () {
                        alert('Error!');
                    }
                });
            },
            ShowField: function (fieldIndex) {
                var Field = $Object.FormRow[fieldIndex];
                if (Field != undefined) {
                    t.fromTo(Field, 0.3, {
                        opacity: 0,
                        x: '-50rem',
                        zIndex: 1,
                        display: 'block',
                        rotationX: 0
                    }, {
                        opacity: 1,
                        x: '0rem',
                        onComplete: function () {
                            $(Field).find('input:not(.SubmitButton), textarea, select').focus();
                        }
                    });
                    t.staggerFromTo($Object.FormRowAnimatingChildren[fieldIndex], 0.3, {
                        opacity: 0,
                        x: '-50rem',
                        rotationX: 45
                    }, {
                        opacity: 1,
                        x: '0rem',
                        rotationX: 0,
                        clearProps: 'all'
                    }, 0.1);
                }
            },
            HideField: function (fieldIndex) {
                var Field = $Object.FormRow[fieldIndex];
                if (Field != undefined) {
                    t.fromTo(Field, 0.3, {
                        opacity: 1,
                        x: '0rem',
                        zIndex: 0
                    }, {
                        opacity: 0,
                        x: '50rem',
                        onComplete: function () {
                            $(Field).css('display', 'none');
                        }
                    });
                }
            },
            Next: function () {
                if (Globals.CurrentField < Globals.LastField) {
                    var $Field = $($Object.FormRow[Globals.CurrentField]).find('input, textarea, select').first();
                    $Field.trigger('input');
                    if (!$Field.hasClass('Required') && !$Field.hasClass('Error')) {
                        $Object.Previous.addClass('Show');
                        Functions.HideField(Globals.CurrentField++);
                        Functions.ShowField(Globals.CurrentField);
                        if (Globals.CurrentField === Globals.LastField) {
                            $Object.Next.removeClass('Show');
                        }
                    }
                } else {
                    $Object.Next.removeClass('Show');
                }
            },
            Previous: function () {
                if (Globals.CurrentField > 0) {
                    $Object.Next.addClass('Show');
                    Functions.HideField(Globals.CurrentField--);
                    Functions.ShowField(Globals.CurrentField);
                    if (Globals.CurrentField === 0) {
                        $Object.Previous.removeClass('Show');
                    }
                } else {
                    $Object.Previous.removeClass('Show');
                }
            },
            InputOnKeyDown: function (event) {
                if (event.keyCode === 13) {
                    var $This = $(this);
                    if ($This.prop('tagName') !== 'TEXTAREA') {
                        if (!(($This.prop('tagName') === 'INPUT') && ($This.attr('type') == 'submit'))) {
                            event.stopPropagation();
                            event.preventDefault();
                            Functions.Next();
                        }
                    }
                }
            },
            BackgroundAnimation: function () {
                t.to($Object.Body, 5, {
                    // Bit Hack for Rounding
                    backgroundColor: Globals.BackgroundColors[(Math.random() * Globals.BackgroundColors.length) | 0],
                    onComplete: Functions.BackgroundAnimation
                });
            }
        };

    $(function () {
        $Object.Body = $('body', d);
        $Object.MainFrame = $('#MainFrame', $Object.Body);
        $Object.RegistrationForm = $('#RegistrationForm', $Object.MainFrame);
        if ($Object.RegistrationForm.length > 0) {
            Globals.RegistrationForm = $Object.RegistrationForm.Form(Functions.RegistrationFormOnSubmit);
            $Object.FormRow = $('.FormRow', $Object.RegistrationForm);
            $Object.FormRowAnimatingChildren = [];
            $Object.FormRow.each(function () {
                $Object.FormRowAnimatingChildren.push($(this).find('.col-sm-12').children().filter(':not(.SubmitButton, label)'));
            });
            if ((Globals.LastField = ($Object.FormRow.length - 1)) >= 0) {
                Functions.ShowField(Globals.CurrentField);
            }
            $Object.Next = $('#Next', $Object.RegistrationForm).on('click', Functions.Next);
            $Object.Previous = $('#Previous', $Object.RegistrationForm).on('click', Functions.Previous);
            $Object.Mobile = $('#Mobile', $Object.RegistrationForm);
            $Object.Mobile
                .intlTelInput({
                    allowDropdown: false,
                    separateDialCode: true,
                    onlyCountries: ['in']
                });
            $Object.InputElements = $('input, textarea, select', $Object.RegistrationForm)
                .on('keydown', Functions.InputOnKeyDown);
            t.staggerFromTo($Object.MainFrame.children(), 0.5, {
                y: '10rem',
                opacity: 0
            }, {
                y: '0rem',
                opacity: 1
            }, 0.3, function () {
                Functions.BackgroundAnimation();
            });
        }
    });
})(jQuery, document, TweenMax);